<?php
$hn = "localhost";
$u  = "root";
$p  = "";
$db = "pemweb-d";

$koneksi_ke_db = mysqli_connect($hn, $u, $p, $db);
